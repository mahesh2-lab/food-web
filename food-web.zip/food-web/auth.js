const SignUp = (e) => {
  const form = document.getElementById("signupForm");
  form.addEventListener("submit", async (e) => {
    e.preventDefault();
    const formData = new FormData(form);
    const data = Object.fromEntries(formData.entries());
    localStorage.setItem("user", JSON.stringify(data));
    console.log("User data saved to localStorage:", data);
    alert("Sign up successful!");
    window.location.href = "index.html";
  });
};

const SignIn = (e) => {
  const form = document.getElementById("signinForm");
  form.addEventListener("submit", async (e) => {
    e.preventDefault();
    const formData = new FormData(form);
    const data = Object.fromEntries(formData.entries());
    const storedUser = JSON.parse(localStorage.getItem("user"));
    if (
      storedUser &&
      storedUser.email === data.email &&
      storedUser.password === data.password
    ) {
      console.log("User signed in successfully:", data);
      alert("Sign in successful!");
    } else {
      console.log("Invalid credentials");
      alert("Invalid credentials");
    }
  });
};

const Logout = () => {
  console.log("User logged out");

  localStorage.removeItem("user");
  alert("logout sucessfully")
  window.location.href = "index.html";
};

const loginStatus = document.getElementById("authStatus");
const storedUser = JSON.parse(localStorage.getItem("user"));

if (storedUser) {
  loginStatus.innerHTML = `
    <h1>Welcome back, ${storedUser.fname}</h1>
    <button onclick="Logout()" class="block bg-[#FF6B35] text-white px-4 py-2 rounded-md hover:bg-[#e55a2a] transition-colors text-center" id="logout">Logout</button>
    `;
} else {
  loginStatus.innerHTML = `
    <a
                          href="auth.html"
                          class="block text-gray-800 hover:text-[#FF6B35] transition-colors mb-2"
                          >Sign In</a
                        >
                        <a
                          href="auth.html"
                          class="block bg-[#FF6B35] text-white px-4 py-2 rounded-md hover:bg-[#e55a2a] transition-colors text-center"
                          >Order Now</a
                        >
    `;
}
